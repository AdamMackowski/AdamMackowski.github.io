"""mycalendar URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("new_short", views.new_short, name = "new_short"),
    path("new_long", views.new_long, name = "new_long"),
    path("add_long_note/<int:project_id>", views.add_long_note, name = "add_long_note"),
    path("delete_project/<int:project_id>", views.delete_project, name = "delete_project"),
    path("privacy_policy_and_terms_of_service", views.rules, name = "rules"),
    path("report_bugs", views.report, name = "repost"),

    #APIS
    path("get_notes", views.get_notes, name="notes"),
    path("delete_notes/<int:note_id>", views.delete_note, name="delete_note"),
    path("get_short", views.get_short, name = "get_short"),
    path("get_week", views.get_week, name = "get_week"),
    path("get_weekday", views.get_weekday, name = "get_weekday"),
    path("get_day", views.get_day, name = "get_day"),
    path("delete_shorts/<int:short_id>", views.delete_short, name="delete_short"),
    path("delete_long/<int:long_id>", views.delete_long, name="delete_long"),
    path("get_deleted", views.get_deleted, name = "get_deleted"),
    path("add_note/<str:cont>", views.new_note, name = "new_note"),
    path("get_color_pal", views.get_pal, name = "get_pal"),
]
