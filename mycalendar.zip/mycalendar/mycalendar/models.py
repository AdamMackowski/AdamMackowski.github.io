from django.contrib.auth.models import AbstractUser
from django.db import models
import datetime
import calendar




class report_bugs(models.Model):
    note = models.TextField()
class User(AbstractUser):
    pal = models.CharField(default = "blue", max_length = 20)
class deleted_notes(models.Model):
    note = models.TextField()
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name = "deleted_note_user")
    def serialize(self):
        return {
            "id": self.id,
            "note": self.note,
        }
class short(models.Model):
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name = "short_User")
    note = models.TextField()
    day = models.DateField()
    hour = models.TimeField()
    def serialize(self):
        return {
            "id": self.id,
            "note": self.note,
            "day": self.day,
            "hour": self.hour,
            "weekday": calendar.weekday(self.day.year, self.day.month, self.day.day),
            "week": self.day.isocalendar()[1]
        }
class Note(models.Model):
    note = models.TextField()
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name = "note_User")
    def serialize(self):
        return {
            "id": self.id,
            "note": self.note,
        }
class Long_notes(models.Model):
    notes = models.TextField()
class Project(models.Model):
    name = models.TextField()
    user = models.ForeignKey(User, on_delete=models.PROTECT, related_name = "long_User")
    notes = models.ManyToManyField(Long_notes, blank = True,related_name="project_notes")

