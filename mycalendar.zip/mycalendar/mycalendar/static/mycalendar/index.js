document.addEventListener('DOMContentLoaded', function() {
    fetch("get_color_pal")
    .then(response => response.json())
    .then(color_pallete => {
            window.color_pal = color_pallete;
            document.querySelector('#notes').style.display = 'none';
            document.querySelector('#short').style.display = 'block';
            document.querySelector('#long').style.display = 'none';
            document.querySelector('#deleted').style.display = 'none';
            document.querySelector('#toggle_long_term').style.borderColor = 'black';
            if (window.color_pal == "blue") {
                document.querySelector('#toggle_short_term').style.borderColor = '#007bff'; 
            }
            if (window.color_pal == "green") {
                document.querySelector('#toggle_short_term').style.borderColor = '#7CFC00'; 
            }
            if (window.color_pal == "red") {
                document.querySelector('#toggle_short_term').style.borderColor = 'red'; 
            }
            if (window.color_pal == "dark") {
                document.querySelector('#toggle_short_term').style.borderColor = 'white'; 
            }
            document.querySelector('#toggle_notes').style.borderColor = 'black';
            document.querySelector('#toggle_deleted').style.borderColor = 'black';
        })
    let week_num = 0;
    document.querySelector('#add_note').addEventListener('click', function() {
        fetch(`add_note/${document.querySelector('#add_note_cont').value}`)
        .then(document.getElementById('note_list').appendChild(document.createElement("li")).appendChild(document.createTextNode(document.querySelector('#add_note_cont').value)))
        .then(document.querySelector('#add_note_cont').value = '')
    })
    load('short', week_num)
    document.querySelector('#prev').addEventListener('click', function() {
        week_num -= 1;
        document.getElementById('Monday_list').innerHTML = '';
        document.getElementById('Tuesday_list').innerHTML = '';
        document.getElementById('Wednesday_list').innerHTML = '';
        document.getElementById('Thursday_list').innerHTML = '';
        document.getElementById('Friday_list').innerHTML = '';
        document.getElementById('Saturday_list').innerHTML = '';
        document.getElementById('Sunday_list').innerHTML = '';

        document.querySelector('#short').style.display = 'block';
        document.querySelector('#long').style.display = 'none';
        document.querySelector('#notes').style.display = 'none';
        document.querySelector('#deleted').style.display = 'none';
        load('short', week_num)
    })
    document.querySelector('#next').addEventListener('click', function() {
        week_num ++;
        document.getElementById('Monday_list').innerHTML = '';
        document.getElementById('Tuesday_list').innerHTML = '';
        document.getElementById('Wednesday_list').innerHTML = '';
        document.getElementById('Thursday_list').innerHTML = '';
        document.getElementById('Friday_list').innerHTML = '';
        document.getElementById('Saturday_list').innerHTML = '';
        document.getElementById('Sunday_list').innerHTML = '';

        document.querySelector('#short').style.display = 'block';
        document.querySelector('#long').style.display = 'none';
        document.querySelector('#notes').style.display = 'none';
        document.querySelector('#deleted').style.display = 'none';
        load('short', week_num)
    })

    document.querySelector('#toggle_long_term').addEventListener('click', function() {
        document.querySelector('#long').style.display = 'block';
        document.querySelector('#short').style.display = 'none';
        document.querySelector('#notes').style.display = 'none';
        document.querySelector('#deleted').style.display = 'none';
    if (window.color_pal == "blue") {
        document.querySelector('#toggle_long_term').style.borderColor = '#007bff'; 
    }
    if (window.color_pal == "green") {
        document.querySelector('#toggle_long_term').style.borderColor = '#7CFC00'; 
    }
    if (window.color_pal == "red") {
        document.querySelector('#toggle_long_term').style.borderColor = 'red'; 
    }
    if (window.color_pal == "dark") {
        document.querySelector('#toggle_long_term').style.borderColor = 'white'; 
    }
        document.querySelector('#toggle_short_term').style.borderColor = 'black';
        document.querySelector('#toggle_notes').style.borderColor = 'black';
        document.querySelector('#toggle_deleted').style.borderColor = 'black';
        load('long', week_num)
    });
    document.querySelector('#toggle_short_term').addEventListener('click', function() {
        document.getElementById('Monday_list').innerHTML = '';
        document.getElementById('Tuesday_list').innerHTML = '';
        document.getElementById('Wednesday_list').innerHTML = '';
        document.getElementById('Thursday_list').innerHTML = '';
        document.getElementById('Friday_list').innerHTML = '';
        document.getElementById('Saturday_list').innerHTML = '';
        document.getElementById('Sunday_list').innerHTML = '';

        document.querySelector('#short').style.display = 'block';
        document.querySelector('#long').style.display = 'none';
        document.querySelector('#notes').style.display = 'none';
        document.querySelector('#deleted').style.display = 'none';
        document.querySelector('#toggle_long_term').style.borderColor = 'black';
    if (window.color_pal == "blue") {
        document.querySelector('#toggle_short_term').style.borderColor = '#007bff'; 
    }
    if (window.color_pal == "green") {
        document.querySelector('#toggle_short_term').style.borderColor = '#7CFC00'; 
    }
    if (window.color_pal == "red") {
        document.querySelector('#toggle_short_term').style.borderColor = 'red'; 
    }
    if (window.color_pal == "dark") {
        document.querySelector('#toggle_short_term').style.borderColor = 'white'; 
    }
        document.querySelector('#toggle_notes').style.borderColor = 'black';
        document.querySelector('#toggle_deleted').style.borderColor = 'black';
        load('short', week_num)
    });
    document.querySelector('#toggle_notes').addEventListener('click', function() {
        document.getElementById('note_list').innerHTML = '';
        document.querySelector('#notes').style.display = 'block';
        document.querySelector('#short').style.display = 'none';
        document.querySelector('#long').style.display = 'none';
        document.querySelector('#deleted').style.display = 'none';
        document.querySelector('#toggle_long_term').style.borderColor = 'black';
        document.querySelector('#toggle_short_term').style.borderColor = 'black';
    if (window.color_pal == "blue") {
        document.querySelector('#toggle_notes').style.borderColor = '#007bff'; 
    }
    if (window.color_pal == "green") {
        document.querySelector('#toggle_notes').style.borderColor = '#7CFC00'; 
    }
    if (window.color_pal == "red") {
        document.querySelector('#toggle_notes').style.borderColor = 'red'; 
    }
    if (window.color_pal == "dark") {
        document.querySelector('#toggle_notes').style.borderColor = 'white'; 
    }
        document.querySelector('#toggle_deleted').style.borderColor = 'black';
        load('notes', week_num)
    });
    document.querySelector('#toggle_deleted').addEventListener('click', function() {
        document.getElementById('deleted_list').innerHTML = '';
        document.querySelector('#notes').style.display = 'none';
        document.querySelector('#short').style.display = 'none';
        document.querySelector('#long').style.display = 'none';
        document.querySelector('#deleted').style.display = 'block';
        document.querySelector('#toggle_long_term').style.borderColor = 'black';
        document.querySelector('#toggle_short_term').style.borderColor = 'black';
        document.querySelector('#toggle_notes').style.borderColor = 'black';
    if (window.color_pal == "blue") {
        document.querySelector('#toggle_deleted').style.borderColor = '#007bff'; 
    }
    if (window.color_pal == "green") {
        document.querySelector('#toggle_deleted').style.borderColor = '#7CFC00'; 
    }
    if (window.color_pal == "red") {
        document.querySelector('#toggle_deleted').style.borderColor = 'red'; 
    }
    if (window.color_pal == "dark") {
        document.querySelector('#toggle_deleted').style.borderColor = 'white'; 
    }
        load('deleted', week_num)
    });
});
function load(type, week_num) {
    //if (type === 'long') {
        
    //} 
    if (type === 'short') {
        fetch("get_day")
        .then(response => response.json())
        .then(day => {
            fetch("get_weekday")
            .then(response => response.json())
            .then(weekday => {

                if (weekday == 0) {
                    document.getElementById('m').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('m').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 1) {
                    document.getElementById('t').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('t').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 2) {
                    document.getElementById('w').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('w').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 3) {
                    document.getElementById('th').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('th').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 4) {
                    document.getElementById('f').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('f').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 5) {
                    document.getElementById('s').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('s').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
                if (weekday == 6) {
                    document.getElementById('su').innerHTML = '';
                    if (week_num == 0) {
                        document.getElementById('su').appendChild(document.createTextNode("  " + day + " (this day)"));    
                    }
                    
                }
            })
        })
        fetch("get_short")
        .then(response => response.json())
        .then(shorts => {
            fetch("get_week")
            .then(response => response.json())
            .then(week => {
                shorts.forEach(function(short) {
                    if (short.week == week + week_num) {
                        var list_object = document.createElement("li")
                        list_object.setAttribute("id", `${short.id}`)
                        list_object.setAttribute("onclick", `short_delete(${short.id})`)
                        if (short.weekday == 0) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3) + ": "))
                            
                            document.getElementById('Monday_list').appendChild(list_object)
                        }
                        if (short.weekday == 1) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                            
                            document.getElementById('Tuesday_list').appendChild(list_object)
                        }
                        if (short.weekday == 2) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                            
                            document.getElementById('Wednesday_list').appendChild(list_object)
                        }
                        if (short.weekday == 3) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                           
                            document.getElementById('Thursday_list').appendChild(list_object)
                        }
                        if (short.weekday == 4) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                            
                            document.getElementById('Friday_list').appendChild(list_object)
                        }
                        if (short.weekday == 5) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                            
                            document.getElementById('Saturday_list').appendChild(list_object)
                        }
                        if (short.weekday == 6) {
                            
                            list_object.appendChild(document.createTextNode(short.hour.slice(0, -3)  + ": "))
                            
                            document.getElementById('Sunday_list').appendChild(list_object)
                        }
                        list_object.appendChild(document.createTextNode(short.note))
                    }
                })
            })
        })
    }
    if (type === 'notes') {
        fetch("get_notes")
        .then(response => response.json())
        .then(notes => {
            notes.forEach(function(note) {
                var list_object = document.createElement("li")
                list_object.setAttribute("id", `note_${note.id}`)
                list_object.appendChild(document.createTextNode(note.note))
                list_object.setAttribute("onclick", `note_delete(${note.id})`)
                document.getElementById('note_list').appendChild(list_object)

            })
        })
    }
    if (type === 'long') {
    }
    if (type === 'deleted') {
        fetch("get_deleted")
        .then(response => response.json())
        .then(deleted => {
            deleted.forEach(function(delete_) {
                var list_object = document.createElement("li")
                list_object.appendChild(document.createTextNode(delete_.note))
                document.getElementById('deleted_list').appendChild(list_object)
            })
        })
    }
}
function note_delete(note_id) {
    fetch(`delete_notes/${note_id}`)
    //.then(window.location.reload(false))
    .then(document.getElementById(`note_${note_id}`).style.display = 'none')
    .then(document.querySelector('#notes').style.display = 'block')
    .then(document.querySelector('#short').style.display = 'none')
    .then(document.querySelector('#long').style.display = 'none')
    .then(document.querySelector('#deleted').style.display = 'none')
}
function short_delete(short_id) {
    document.getElementById(`${short_id}`).style.display = 'none';
    fetch(`delete_shorts/${short_id}`)
    //.then(window.location.reload(false))
    .then(document.querySelector('#short').style.display = 'block')
    .then(document.querySelector('#notes').style.display = 'none')
    .then(document.querySelector('#long').style.display = 'none')
    .then(document.querySelector('#deleted').style.display = 'none')
}
function delete_long(long_id) {
    fetch(`delete_long/${long_id}`)
    .then(document.getElementById(`${long_id}`).style.display = 'none')
}
function delete_project(project_id) {
    fetch(`delete_project/${project_id}`)
    .then(document.getElementById(`project_id_${project_id}`).style.display = 'none')
}