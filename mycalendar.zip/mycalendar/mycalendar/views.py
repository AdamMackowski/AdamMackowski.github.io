import json
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db import IntegrityError
from django.http import JsonResponse
from django.shortcuts import HttpResponse, HttpResponseRedirect, render
from django.urls import reverse
from django.views.decorators.csrf import csrf_exempt
from django.core.serializers.json import DjangoJSONEncoder
import datetime
import calendar
#datetime.datetime(1900,1,1)
from .models import User, Note, short, Project, Long_notes, deleted_notes, report_bugs

def report(request):
    if request.method == 'POST':
        report_bugs.objects.create(note = request.POST['note'])
        return HttpResponseRedirect(reverse("index"))
    return render(request, "mycalendar/report.html")
def get_pal(request):
    color_pallete = request.user.pal
    return JsonResponse(color_pallete, safe = False)
def new_note(request, cont):
    note = Note.objects.create(user = request.user, note = cont)
    return JsonResponse({"message": "added"})
def get_deleted(request):
    deleted = reversed(deleted_notes.objects.filter(user = request.user))
    return JsonResponse([delete_.serialize() for delete_ in deleted], safe = False)
def rules(request):
    return render(request, "mycalendar/rules.html")
def delete_project(request, project_id):
    if request.user.is_authenticated is False:
        return HttpResponseRedirect(reverse("login"))
    project = Project.objects.get(pk= project_id)
    deleted_notes.objects.create(user = request.user, note = project.notes.all)
    if project.user != request.user:
        return HttpResponseRedirect(reverse("index"))
    project.delete()
    return JsonResponse({"message": "deleted project"})
def add_long_note(request, project_id):
    if request.user.is_authenticated is False:
        return HttpResponseRedirect(reverse("login"))
    project = Project.objects.get(pk= project_id)
    if project.user != request.user:
        return HttpResponseRedirect(reverse("index"))
    if request.method == "POST":
        task = request.POST["task"]
        try:
            long_note = Long_notes.objects.create(notes = task)
            project.notes.add(long_note)
        except:
            pass
       
        return HttpResponseRedirect(reverse("index"))
    return render(request, "mycalendar/add_long.html")
def new_long(request):
    if request.user.is_authenticated is False:
        return HttpResponseRedirect(reverse("login"))
    if request.method == "POST":
        name = request.POST["name"]
        try:
            Project.objects.create(user = request.user, name = name)
        except:
            pass
        return HttpResponseRedirect(reverse("index"))
    return render(request, "mycalendar/new_long.html")
def delete_long(request, long_id):
    this_long = Long_notes.objects.get(pk = long_id)
    deleted_notes.objects.create(user = request.user, note = this_long.notes)
    this_long.delete()

    return JsonResponse({"message": "deleted"})
def new_short(request):
    if request.user.is_authenticated is False:
        return HttpResponseRedirect(reverse("login"))
    if request.method == "POST":
        day = request.POST["day"]
        month = request.POST["month"]
        year = request.POST["year"]

        time = request.POST["hour"]
        note = request.POST["note"]
        try:
            short.objects.create(user = request.user, note = note, day = year + "-" + month + "-" + day, hour = time)
        except:
            pass
        return HttpResponseRedirect(reverse("index"))
    return render(request, "mycalendar/new_short.html")
def delete_short(request, short_id):
    this_short = short.objects.get(pk = short_id)
    deleted_notes.objects.create(user = request.user, note = this_short.note)
    if this_short.user != request.user:
        return HttpResponseRedirect(reverse("index"))
    this_short.delete()
    return JsonResponse({"message": "deleted"})
def get_day(request):
    day = datetime.date.today()
    return JsonResponse(day, safe = False)
def get_weekday(request):
    weekday = calendar.weekday(datetime.date.today().year, datetime.date.today().month, datetime.date.today().day)
    return JsonResponse(weekday, safe = False)
def get_week(request):
    week = datetime.date.today().isocalendar()[1]
    return JsonResponse(week, safe = False)
def get_short(request):
    shorts = short.objects.filter(user = request.user)
    shorts = shorts.order_by("hour").all()
    return JsonResponse([short.serialize() for short in shorts], safe = False)
def delete_note(request, note_id):
    note = Note.objects.get(pk = note_id)
    deleted_notes.objects.create(user = request.user, note = note.note)
    if note.user != request.user:
        return HttpResponseRedirect(reverse("index"))
    note.delete()
    return JsonResponse({"message": "deleted"})
def get_notes(request):
    notes = Note.objects.filter(user = request.user)
    return JsonResponse([note.serialize() for note in notes], safe = False)
def index(request):
    if request.user.is_authenticated:
        if request.method == 'POST':
            request.user.pal = request.POST['pal']
            request.user.save()
        Projects = Project.objects.filter(user = request.user)
        context = {
            "Projects": Projects
        }
        return render(request, "mycalendar/index.html", context)

    # Everyone else is prompted to sign in
    else:
        return HttpResponseRedirect(reverse("login"))

def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        name = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=name, password=password)
        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "mycalendar/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "mycalendar/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        name = request.POST["name"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        email = request.POST["email"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "mycalendar/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(name, email,password)
            user.save()
            short.objects.create(note = "here you can add notes, just as it is a calendar, by clicking on the + button. To mark a note as done/not useful anymore you can click on the note.", user = user, hour = "12:12", day = datetime.date.today())
            Project.objects.create(name = "here you can add a project, and tasks accosiated to it. To add a task click on the plus button next to project's name." ,user = user )
            Note.objects.create(note = "here you can just add notes", user = user)
        except IntegrityError as e:
            print(e)
            return render(request, "mycalendar/register.html", {
                "message": "Email address already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "mycalendar/register.html")