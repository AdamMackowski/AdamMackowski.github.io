from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from urllib.parse import unquote
from .models import User, all_auctions,bids,comments,categoriess
from decimal import Decimal



def category_view(request):
    categs = categoriess.objects.all()
    context = {
        "all_categories": categs
    }
    return render(request, "auctions/category.html", context)
def index(request):
    auctions_list = all_auctions.objects.all()
    if request.method == "POST":
        search = request.POST["categories_find"]
        search = unquote(search)
        auctions_list = all_auctions.objects.filter(category__icontains=search, ended__icontains="False")
    else:
        auctions_list = all_auctions.objects.filter(ended__icontains="False")     #NEEDS CHECK
    context = {
        "auctions_list": auctions_list
    }
    return render(request, "auctions/index.html", context)
def watchlist(request):
    watchlist_list = request.user.watchlist.all()
    context = {
        "watchlist_list": watchlist_list
    }
    return render(request, "auctions/watchlist.html", context)
def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")
def create_auction(request):
    if request.method == "POST":
        title = request.POST["title"]
        description = request.POST["description"]
        photo_url = request.POST["photo_url"]
        categories = request.POST["categories"]
        try:
            categoriess.objects.create(categ = categories)
        except:
            pass
        auction = all_auctions.objects.create(title = title, description = description, photo_url = photo_url, category = categories)
        auction.save()
        request.user.created.add(auction)
        try:
            bid = request.POST["current_bid"]
            all_bid = bids.objects.create(bid = bid)
            auction.bid.add(all_bid)
        except:
            bid = 0.00
            all_bid = bids.objects.create(bid = bid)
            auction.bid.add(all_bid)
        return HttpResponseRedirect(reverse("index"))
    return render(request, "auctions/create_auction.html")
def dynamic_listings_view(request, my_id):
    auction = all_auctions.objects.get(id= my_id)
    comment_num = auction.comments.all().count()
    bid_num = len(auction.bid.all())
    bid_num -= 1
    all_comments = auction.comments.all()
    if request.method == "POST" and "bid" in request.POST:
        if request.user.is_authenticated:
            highest_bid = request.POST["bid"]
            if int(float(highest_bid)) > int(auction.bid.all()[bid_num].bid):
                all_bid = bids.objects.create(bid = highest_bid)
                auction.bid.add(all_bid)
                for mmm in User.objects.all():
                    try:
                        mmm.user_bid.remove(auction)
                    except:
                        pass
                request.user.user_bid.add(auction)
    if request.method == "POST" and "watch"in request.POST:
        if request.user.is_authenticated:
            if auction not in request.user.watchlist.all():
                request.user.watchlist.add(auction)
            else:
                request.user.watchlist.remove(auction)
    if request.method == "POST" and "comment" in request.POST:
        comment = request.POST["comment"]
        if request.user.is_authenticated:
            comment_now = comments.objects.create(comment = comment)
            auction.comments.add(comment_now)
    if request.method == "POST" and "end_auction" in request.POST:
        auction.ended = True
        auction.save()
    try:
        context = {
            "auction": auction,
            "bid_auction": auction.bid.all(),
            "comment_num": comment_num,
            "all_comments": all_comments,
            "who_created": request.user.created.all(),
            "users_auctions": request.user.user_bid.all()
            }
    except:
        context = {
            "auction": auction,
            "bid_auction": auction.bid.all(),
            "comment_num": comment_num,
            "all_comments": all_comments,
            }
    return render(request, "auctions/dynamic_auction.html", context)
