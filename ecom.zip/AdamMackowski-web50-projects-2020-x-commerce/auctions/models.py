from django.contrib.auth.models import AbstractUser
from django.db import models

class comments(models.Model):
    comment = models.TextField(blank=False)
class bids(models.Model):
    bid = models.DecimalField(decimal_places = 2, max_digits = 100000)
class all_auctions(models.Model):
    category = models.CharField(max_length= 14, default = "none")
    title = models.CharField(max_length= 14)
    description = models.TextField(blank=False)
    photo_url = models.CharField(max_length= 500000)
    bid = models.ManyToManyField(bids, blank = True, related_name = "bid_auction")
    comments = models.ManyToManyField(comments, blank = True, related_name = "comments")
    ended = models.CharField(max_length= 14, default = "False")
class User(AbstractUser):
    #username_per = models.CharField(max_length= 14)
    #email_per    = models.CharField(max_length= 14)
    #password_per = models.CharField(max_length= 14)
    created =  models.ManyToManyField(all_auctions, blank = True, related_name = "created")
    watchlist = models.ManyToManyField(all_auctions, blank = True, related_name = "watchlist")
    user_bid = models.ManyToManyField(all_auctions, blank = True, related_name = "bidder")
    #user_comment
class categoriess(models.Model):
    categ = models.CharField(max_length= 14)
