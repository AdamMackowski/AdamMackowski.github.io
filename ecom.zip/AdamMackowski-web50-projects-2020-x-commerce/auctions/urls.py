from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("login", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("create_auction", views.create_auction, name="create_auction"),
    path("watchlist", views.watchlist, name="watchlist"),
    path('listing/<int:my_id>/', views.dynamic_listings_view, name = 'dynamic_listings_view'),
    path('categories/', views.category_view, name = "category_view")
]
