from django.contrib import admin

from .models import User
from .models import all_auctions
from .models import bids
from .models import comments
admin.site.register(User)
admin.site.register(all_auctions)
admin.site.register(bids)
admin.site.register(comments)
